# kit-facas-pro

## Rodar local
```bash
npm install
npm run dev
```

## Deploy (Vercel)
```bash
npm run build
npx vercel deploy --prod
```

Edite dados em `src/App.tsx` se necessário.
