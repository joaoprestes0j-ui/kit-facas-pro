import React, { useEffect, useMemo, useState, type ReactNode } from "react";
import { CheckCircle, Truck, Shield, CreditCard, MessageCircle, Clock } from "lucide-react";

const PLACEHOLDER_IMG = "https://drive.google.com/uc?export=view&id=18dAG94MswljyW0se3wDfYWts7PXgZi7K";
const PLACEHOLDER_GALLERY: string[] = ["https://drive.google.com/uc?export=view&id=18dAG94MswljyW0se3wDfYWts7PXgZi7K", "https://drive.google.com/uc?export=view&id=18dAG94MswljyW0se3wDfYWts7PXgZi7K", "https://drive.google.com/uc?export=view&id=18dAG94MswljyW0se3wDfYWts7PXgZi7K"];

function formatHMS(ms: number) {
  const h = Math.max(0, Math.floor(ms / 1000 / 3600));
  const m = Math.max(0, Math.floor((ms / 1000 / 60) % 60));
  const s = Math.max(0, Math.floor((ms / 1000) % 60));
  return [h, m, s].map((n) => String(n).padStart(2, "0")) as [string, string, string];
}

function ensureImage(url?: string) {
  if (!url) return PLACEHOLDER_IMG;
  const lower = url.toLowerCase();
  const isLocalFile = lower.startsWith("file:");
  const isPdf = lower.endsWith(".pdf");
  const isHttp = lower.startsWith("http://") || lower.startsWith("https://");
  if (isLocalFile || isPdf || !isHttp) return PLACEHOLDER_IMG;
  return url;
}

function safeGallery(g?: string[]) {
  if (!Array.isArray(g)) return [] as string[];
  return g.filter(Boolean);
}

export default function App() {
  const CONFIG = {
    brand: "Ofertas Prime",
    productName: "Kit de Facas Profissional — 6 peças",
    priceFrom: 189.9,
    priceTo: 129.9,
    checkoutUrl: "https://entrega.logzz.com.br/pay/memxl5dmm/1-kit-com-6-facas-promocao",
    whatsappUrl: "https://wa.me/5541998798091?text=Ol%C3%A1%21%20Quero%20agendar%20a%20entrega%20do%20Kit%20de%20Facas%20%28pague%20na%20entrega%29.",
    heroImage: "https://drive.google.com/uc?export=view&id=18dAG94MswljyW0se3wDfYWts7PXgZi7K",
    gallery: ["https://drive.google.com/uc?export=view&id=18dAG94MswljyW0se3wDfYWts7PXgZi7K", "https://drive.google.com/uc?export=view&id=18dAG94MswljyW0se3wDfYWts7PXgZi7K", "https://drive.google.com/uc?export=view&id=18dAG94MswljyW0se3wDfYWts7PXgZi7K"] as string[]
  } as const;

  const heroSrc = ensureImage(CONFIG.heroImage);
  const gallery = safeGallery(CONFIG.gallery);

  const target = useMemo(() => {
    const t = new Date();
    t.setHours(23, 59, 59, 999);
    return t;
  }, []);

  const [left, setLeft] = useState<number>(target.getTime() - Date.now());
  useEffect(() => {
    const id = setInterval(() => setLeft(target.getTime() - Date.now()), 250);
    return () => clearInterval(id);
  }, [target]);

  const [hh, mm, ss] = formatHMS(left);

  return (
    <div className="min-h-screen bg-white text-neutral-900">
      <div className="sticky top-0 z-50 w-full bg-emerald-600 text-white text-sm md:text-base shadow">
        <div className="mx-auto max-w-6xl px-4 py-2 flex items-center justify-center gap-2 font-semibold">
          <CreditCard className="h-4 w-4" />
          <span>PAGUE NA ENTREGA</span>
          <span className="opacity-80">•</span>
          <Truck className="h-4 w-4" />
          <span>Frete grátis em regiões selecionadas</span>
        </div>
      </div>

      <header className="mx-auto max-w-6xl px-4 py-6 flex items-center justify-between">
        <div className="font-bold tracking-tight text-xl">{CONFIG.brand}</div>
        <a href={CONFIG.checkoutUrl} className="inline-flex items-center gap-2 rounded-2xl bg-emerald-600 px-5 py-3 text-white font-semibold shadow hover:brightness-110">
          QUERO APROVEITAR A OFERTA
        </a>
      </header>

      <section className="mx-auto max-w-6xl px-4 grid md:grid-cols-2 gap-8 items-center">
        <div className="aspect-square overflow-hidden rounded-3xl shadow-lg">
          <img
            src={heroSrc}
            alt={CONFIG.productName}
            className="h-full w-full object-cover"
            onError={(e) => {
              (e.currentTarget as HTMLImageElement).src = PLACEHOLDER_IMG;
            }}
          />
        </div>
        <div>
          <div className="mb-3 text-xs uppercase tracking-widest text-emerald-700 font-semibold">Oferta exclusiva</div>
          <h1 className="text-3xl md:text-4xl font-extrabold leading-tight">{CONFIG.productName}</h1>
          <p className="mt-3 text-neutral-700">Conjunto completo para o dia a dia: lâminas afiadas, acabamento premium e cabo ergonômico para máximo controle e segurança no corte.</p>
          <div className="mt-5 flex items-end gap-4">
            <div>
              <div className="text-sm line-through text-neutral-500">de R$ {CONFIG.priceFrom.toFixed(2)}</div>
              <div className="text-4xl font-extrabold text-emerald-700">por R$ {CONFIG.priceTo.toFixed(2)}</div>
              <div className="text-sm text-neutral-600">Pague somente na entrega</div>
            </div>
            <div className="ml-auto">
              <div className="flex items-center gap-2 text-sm text-neutral-600">
                <Clock className="h-4 w-4" />
                <span>Termina em</span>
              </div>
              <div className="text-2xl font-bold tabular-nums">{hh}:{mm}:{ss}</div>
            </div>
          </div>
          <div className="mt-6 flex flex-wrap gap-3">
            <a href={CONFIG.checkoutUrl} className="inline-flex items-center justify-center rounded-2xl bg-emerald-600 px-6 py-3 text-white font-semibold shadow hover:brightness-110 w-full sm:w-auto">
              QUERO APROVEITAR A OFERTA
            </a>
            <a href={CONFIG.whatsappUrl} className="inline-flex items-center justify-center gap-2 rounded-2xl border border-neutral-300 px-6 py-3 font-semibold hover:bg-neutral-50 w-full sm:w-auto">
              <MessageCircle className="h-4 w-4" /> Tirar dúvidas no WhatsApp
            </a>
          </div>
          <div className="mt-6 grid grid-cols-1 sm:grid-cols-3 gap-3">
            <TrustBadge icon={<CreditCard className="h-5 w-5" />} title="Pague na entrega" subtitle="Sem pagamento antecipado" />
            <TrustBadge icon={<Truck className="h-5 w-5" />} title="Frete grátis" subtitle="Consulte regiões" />
            <TrustBadge icon={<Shield className="h-5 w-5" />} title="Garantia" subtitle="7 dias de satisfação" />
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-4 mt-12">
        <h2 className="text-2xl font-bold">Por que escolher este kit?</h2>
        <div className="mt-6 grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <Benefit title="Facas com alto poder de corte" />
          <Benefit title="Aço resistente e durável" />
          <Benefit title="Cabos ergonômicos e confortáveis" />
          <Benefit title="Acabamento premium" />
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-4 mt-12">
        <h2 className="text-2xl font-bold">O kit acompanha</h2>
        <ul className="mt-4 grid md:grid-cols-2 gap-3 text-neutral-800">
          <KitItem>1 Faca de cozinha</KitItem>
          <KitItem>1 Faca para fatiar</KitItem>
          <KitItem>1 Faca do chef</KitItem>
          <KitItem>1 Faca para aparar</KitItem>
          <KitItem>1 Descascador de legumes</KitItem>
          <KitItem>1 Tesoura multiuso</KitItem>
        </ul>
        <div className="mt-6 grid sm:grid-cols-3 gap-4">
          {(gallery.length ? gallery : PLACEHOLDER_GALLERY).map((src, i) => (
            <div key={i} className="aspect-[4/3] overflow-hidden rounded-2xl border">
              <img
                src={ensureImage(src)}
                alt={`Imagem ${i + 1}`}
                className="h-full w-full object-cover"
                onError={(e) => {
                  (e.currentTarget as HTMLImageElement).src = PLACEHOLDER_GALLERY[i % PLACEHOLDER_GALLERY.length];
                }}
              />
            </div>
          ))}
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-4 mt-12">
        <div className="rounded-3xl bg-neutral-50 p-6 border">
          <h2 className="text-2xl font-bold">Como funciona o Pague na Entrega</h2>
          <ol className="mt-4 grid md:grid-cols-3 gap-4 text-neutral-800">
            <Step n={1} text="Você agenda a entrega pelo botão acima." />
            <Step n={2} text="Nossa equipe confirma os dados e despacha o pedido." />
            <Step n={3} text="Você paga ao receber o produto, direto com o entregador." />
          </ol>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-4 mt-12">
        <div className="rounded-3xl bg-emerald-600 text-white p-6 flex flex-col md:flex-row items-center gap-4">
          <div className="text-xl font-bold">Últimas unidades com frete grátis</div>
          <div className="opacity-90">Garanta o seu agora mesmo</div>
          <a href={CONFIG.checkoutUrl} className="md:ml-auto inline-flex items-center justify-center rounded-2xl bg-white text-emerald-700 font-semibold px-6 py-3 hover:brightness-110">
            AGENDAR ENTREGA
          </a>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-4 mt-12">
        <h2 className="text-2xl font-bold">Dúvidas frequentes</h2>
        <div className="mt-6 divide-y">
          <SimpleFaq q="É realmente pago só na entrega?" a="Sim. Você agenda, recebe a confirmação e paga somente ao receber o produto." />
          <SimpleFaq q="Qual o prazo de entrega?" a="Em média 1–5 dias úteis após a confirmação do agendamento, dependendo da região." />
          <SimpleFaq q="Tem frete grátis?" a="Oferecemos frete grátis para regiões selecionadas. Confira disponibilidade no checkout." />
          <SimpleFaq q="Qual a política de troca/garantia?" a="7 dias para trocas/devoluções por arrependimento conforme CDC. Itens devem estar sem uso e com embalagem." />
        </div>
      </section>

      <footer className="mx-auto max-w-6xl px-4 mt-16 mb-10 text-sm text-neutral-600">
        <div className="flex flex-wrap items-center gap-3">
          <span>© {new Date().getFullYear()} {CONFIG.brand}</span>
          <span className="opacity-50">•</span>
          <a href="#" className="hover:underline">Política de Privacidade</a>
          <span className="opacity-50">•</span>
          <a href="#" className="hover:underline">Termos de Uso</a>
          <span className="opacity-50">•</span>
          <a href={CONFIG.whatsappUrl} className="inline-flex items-center gap-1 hover:underline">
            <MessageCircle className="h-4 w-4" /> Suporte
          </a>
        </div>
      </footer>
    </div>
  );
}

function TrustBadge({ icon, title, subtitle }: { icon: ReactNode; title: string; subtitle: string }) {
  return (
    <div className="rounded-2xl border p-4 bg-white flex items-start gap-3">
      <div className="mt-0.5">{icon}</div>
      <div>
        <div className="font-semibold">{title}</div>
        <div className="text-sm text-neutral-600">{subtitle}</div>
      </div>
    </div>
  );
}

function Benefit({ title }: { title: string }) {
  return (
    <div className="rounded-2xl border p-4 bg-white flex items-start gap-3">
      <CheckCircle className="h-5 w-5" />
      <div className="font-medium">{title}</div>
    </div>
  );
}

function KitItem({ children }: { children: ReactNode }) {
  return (
    <li className="flex items-start gap-2">
      <CheckCircle className="h-5 w-5 text-emerald-600 shrink-0" />
      <span>{children}</span>
    </li>
  );
}

function Step({ n, text }: { n: number; text: string }) {
  return (
    <li className="rounded-2xl bg-white border p-4">
      <div className="text-emerald-700 font-extrabold text-xl">{n}</div>
      <div className="mt-1 text-neutral-800">{text}</div>
    </li>
  );
}

function SimpleFaq({ q, a }: { q: string; a: string }) {
  return (
    <details className="py-3">
      <summary className="cursor-pointer list-none font-semibold flex items-center justify-between">
        <span>{q}</span>
        <span className="text-neutral-400">+</span>
      </summary>
      <p className="mt-2 text-neutral-700">{a}</p>
    </details>
  );
}
